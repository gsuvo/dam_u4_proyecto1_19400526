import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto1_19400526/pages/add_vehiculo.dart';
import '../services/firebase_service.dart';
class vehiculo extends StatefulWidget {
  const vehiculo({Key? key}) : super(key: key);

  @override
  State<vehiculo> createState() => _vehiculoState();
}

class _vehiculoState extends State<vehiculo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
          future: getVehiculo(),
          builder: ((context, snapshot){
            if(snapshot.hasData) {
              return ListView.builder(
                itemCount: snapshot.data?.length,
                itemBuilder: (context, index) {
                  return Card(
                    margin: EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.all(5),
                          color: Colors.orangeAccent,
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(snapshot.data?[index]['trabajador']),
                              ),
                              IconButton(
                                icon: Icon(Icons.edit),
                                onPressed: () {
                                  setState(() {});
                                },
                              ),
                              IconButton(
                                icon: Icon(Icons.delete),
                                onPressed: () {},
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 5,width: 5),
                        Text('Combustible: ${snapshot.data?[index]['combustible']}'),
                        SizedBox(height: 5,width: 5),
                        Text('Departamento: ${snapshot.data?[index]['depto']}'),
                        SizedBox(height: 5,width: 5),
                        Text('No. Serie: ${snapshot.data?[index]['numeroserie']}'),
                        SizedBox(height: 5,width: 5),
                        Text('Placa: ${snapshot.data?[index]['placa']}'),
                        SizedBox(height: 5,width: 5),
                        Text('Resguardado por: ${snapshot.data?[index]['resguardadopor']}'),
                        SizedBox(height: 5,width: 5),
                        Text('Tanque: ${snapshot.data?[index]['tanque']}'),
                        SizedBox(height: 5,width: 5),
                        Text('Tipo: ${snapshot.data?[index]['tipo']}'),
                      ],
                    ),
                  );
                },
              );
            }else{
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
          })),
      floatingActionButton: FloatingActionButton(
        onPressed: () async{
         await Navigator.pushNamed(context, '/add');
         setState(() {

         });
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
