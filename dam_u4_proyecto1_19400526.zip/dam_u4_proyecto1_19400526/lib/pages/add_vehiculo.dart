import 'package:dam_u4_proyecto1_19400526/services/firebase_service.dart';
import 'package:flutter/material.dart';

class AddVehiculo extends StatefulWidget {
  const AddVehiculo({Key? key}) : super(key: key);

  @override
  State<AddVehiculo> createState() => _AddVehiculoState();
}

class _AddVehiculoState extends State<AddVehiculo> {
  TextEditingController combustibleCon = TextEditingController(text: "");
  TextEditingController deptoCon = TextEditingController(text: "");
  TextEditingController numeroserieCon = TextEditingController(text: "");
  TextEditingController placaCon = TextEditingController(text: "");
  TextEditingController resguardadoporCon = TextEditingController(text: "");
  TextEditingController tanqueCon = TextEditingController(text: "");
  TextEditingController tipoCon = TextEditingController(text: "");
  TextEditingController trabajadorCon = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Agregar Vehículo'),
        backgroundColor: Colors.deepOrange,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: combustibleCon,
              decoration: const InputDecoration(
                labelText: 'Combustible',
              ),
            ),
            TextField(
              controller: deptoCon,
              decoration: const InputDecoration(
                labelText: 'Departamento',
              ),
            ),
            TextField(
              controller: numeroserieCon,
              decoration: const InputDecoration(
                labelText: 'Número de Serie',
              ),
            ),
            TextField(
              controller: placaCon,
              decoration: const InputDecoration(
                labelText: 'Placa',
              ),
            ),
            TextField(
              controller: resguardadoporCon,
              decoration: const InputDecoration(
                labelText: 'Resguardado por',
              ),
            ),
            TextField(
              controller: tanqueCon,
              decoration: const InputDecoration(
                labelText: 'Tanque',
              ),
            ),
            TextField(
              controller: tipoCon,
              decoration: const InputDecoration(
                labelText: 'Tipo',
              ),
            ),
            TextField(
              controller: trabajadorCon,
              decoration: const InputDecoration(
                labelText: 'Trabajador',
              ),
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () async {
                await addVehiculo(combustibleCon.text, deptoCon.text, numeroserieCon.text, placaCon.text, resguardadoporCon.text, int.parse(tanqueCon.text), tipoCon.text, trabajadorCon.text).then((_) {
                  Navigator.pop(context);
                });
                 
                },
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
  }
}
