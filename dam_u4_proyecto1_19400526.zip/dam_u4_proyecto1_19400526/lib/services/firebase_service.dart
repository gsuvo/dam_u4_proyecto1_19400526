import 'package:cloud_firestore/cloud_firestore.dart';

FirebaseFirestore db= FirebaseFirestore.instance;
//Leer
Future<List>getVehiculo() async{
  List vehiculo=[];print("hola");

  //pedir todos los elementos de una coleción
  QuerySnapshot queryVehiculo = await db.collection('vehiculo').get();

  for (var doc in queryVehiculo.docs){
    final Map<String, dynamic> data = doc.data() as Map<String,dynamic>;
    final vehic = {
      "combustible": data['combustible'],
      "depto": data['depto'],
      "numeroserie": data['numeroserie'],
      "placa": data['placa'],
      "resguardadopor": data['resguardadopor'],
      "tanque": data['tanque'],
      "tipo": data['tipo'],
      "trabajador": data['trabajador'],
      "uid": doc.id,
    };
    vehiculo.add(vehic);
  }
  return vehiculo;
}
//Guardar
Future<void>addVehiculo(String com,String dep, String num, String pla, String res, int tan, String tip,String tra ) async{
  await db.collection("vehiculo").add({
    "combustible": com,
    "depto": dep,
    "numeroserie": num,
    "placa": pla,
    "resguardadopor": res,
    "tanque": tan,
    "tipo": tip,
    "trabajador": tra
  });
}
//Actualizar
Future<void>updateVehiculo(String com,String dep, String num, String pla, String res, int tan, String tip,String tra, String uid) async{
  await db.collection("vehiculo").doc(uid).set({
    "combustible": com,
    "depto": dep,
    "numeroserie": num,
    "placa": pla,
    "resguardadopor": res,
    "tanque": tan,
    "tipo": tip,
    "trabajador": tra
  });
}